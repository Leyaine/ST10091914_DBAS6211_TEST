Create schema if not exists VesselVoyage; 
use VesselVoyage;
create table Ship (
ShipID INT auto_increment PRIMARY KEY NOT NULL,
IMONumber char(11),
Name varchar(255)
);

alter table Ship 
change column ship IMONumber char(11) not null;

create table Voyage (
VoyageID INT auto_increment PRIMARY KEY NOT NULL,
foreign key (ShipID) REFERENCES Ship(ShipID),
DepartureDate date,
ArrivalDate date,

INSERT into Ship (ShipID, IMONumber, Name)
values (1, "IMO 1234567","Queen of the seven seas");

INSERT INTO Voyage ( VoyageID, ShipID, DepartureDate,ArrivalDate)
values (1,1, "2023-01,01","2023-03-04");




